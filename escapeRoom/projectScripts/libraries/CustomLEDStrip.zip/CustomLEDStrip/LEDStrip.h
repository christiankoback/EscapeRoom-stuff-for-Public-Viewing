

#ifndef CUSTOMLEDSTRIP
#define CUSTOMLEDSTRIP

#include <Arduino.h>
/* Class: LED_strip
Pins: ALL PWM capable pins
Description:  Controls LED strip. Hardware in Escape Room Documents.
Functionality : All color values must be between 0(LED off) and 255(LED full brightness). 
*/
class LED_strip{
	public:
		void LEDStrip_setPins(int redPinIN, int bluePinIN, int greenPinIN);
		int checkColorValue(int colorValue);
		int changeColorAll(int redColor, int blueColor, int greenColor);
		int turnOnColor(char color, int value);
		LED_strip();
	private:
		int redPin;
		int bluePin;
		int greenPin;
};




#endif