
#include "LEDStrip.h"

/*Implementation to use LED strip with Arduino
Requires : 3x PWM pin
*/
LED_strip::LED_strip(){
	
}
void LED_strip::LEDStrip_setPins(int redPinIN, int bluePinIN, int greenPinIN){
	redPin = redPinIN;
	bluePin = bluePinIN;
	greenPin = greenPinIN;
	pinMode(redPin, OUTPUT);
	pinMode(bluePin, OUTPUT);
	pinMode(greenPin, OUTPUT);
}
int LED_strip::checkColorValue(int colorValue){
	if( (colorValue >= 0 ) && (colorValue <= 255) ){
		return 1;
	}
	else{ 
		return 0;
	}
}
int LED_strip::changeColorAll(int redColor, int blueColor, int greenColor){
	if(  ( checkColorValue(redColor) == 1) && ( checkColorValue(blueColor) == 1) && ( checkColorValue(greenColor) == 1) )
	{
		analogWrite(redPin,redColor);
		analogWrite(bluePin,redColor);
		analogWrite(greenPin,redColor);
		return 1;
	}
	else{
		return 0;
	}
}
int LED_strip::turnOnColor(char colorPin, int color){
	if(   checkColorValue(color) == 1){
		if ( 'r' == colorPin) {
			analogWrite(redPin,color);
			return 1;
		}
		else if ('b' == colorPin) {
			analogWrite(bluePin,color);
			return 1;
		}
		else if ('g' == colorPin) {
			analogWrite(greenPin,color);
			return 1;
		}
		else{
			return 0;
		}
	}
	else{
		return 0;
	}
}
