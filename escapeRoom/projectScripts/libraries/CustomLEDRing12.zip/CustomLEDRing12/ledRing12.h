
#ifndef CUSTOMLEDRING
#define CUSTOMLEDRING

#include <Adafruit_NeoPixel.h>		//for LED_Ring12 class

#define NUM_LEDS 12
#define PIN 9

void fadeInColor(int color, int fadeDelay = 2);
void fadeOutColor(int color, int fadeDelay = 2);
void rainbowInRotatingWheel(int rainbowLoops, int rotatingDelayMin, int rotatingDelayIncrement);
void rainbowInRotatingWheel2White(int rainbowLoops, int rotatingDelayMin, int rotatingDelayIncrement);
void changeLEDColor(int ledNum, int redColor, int blueColor, int greenColor);
void changeColor_Uniform(int redColor, int blueColor, int greenColor);
void updateRing();
uint32_t Wheel(byte WheelPos);
uint8_t red(uint32_t c);
uint8_t green(uint32_t c);
uint8_t blue(uint32_t c);
uint8_t white(uint32_t c);
#endif